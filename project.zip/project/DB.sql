-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2019 at 04:10 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `instruments`
--
CREATE DATABASE IF NOT EXISTS `instruments` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `instruments`;

-- --------------------------------------------------------

--
-- Table structure for table `instru`
--

DROP TABLE IF EXISTS `instru`;
CREATE TABLE `instru` (
  `Institute` varchar(50) DEFAULT NULL,
  `Category` varchar(20) DEFAULT NULL,
  `Instument_Type` varchar(20) DEFAULT NULL,
  `ID` varchar(5) NOT NULL,
  `Model` varchar(30) DEFAULT NULL,
  `Fee` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instru`
--

INSERT INTO `instru` (`Institute`, `Category`, `Instument_Type`, `ID`, `Model`, `Fee`) VALUES
('Medical Research Institute', 'Microbiology', 'Centrifuge', 'C0001', 'Liston C 2201', 150000),
('Medical Research Institute', 'Microbiology', 'Centrifuge', 'C0002', 'Liston C 2202', 200000),
('Medical Research Institute', 'Microbiology', 'Centrifuge', 'C0003', 'Liston C 2202', 250000),
('Medical Research Institute', 'Microbiology', 'Centrifuge', 'C0004', 'Liston C 2203', 150000),
('Rubber Research Institute of Sri Lanka', 'Microbiology', 'Microscope', 'M0001', 'AmScope M150C-I', 40000),
('Rubber Research Institute of Sri Lanka', 'Microbiology', 'Microscope', 'M0002', 'AmScope M150C-I', 30000),
('Rubber Research Institute of Sri Lanka', 'Microbiology', 'Microscope', 'M0003', 'AmScope M150C-I', 35000),
('Rubber Research Institute of Sri Lanka', 'Microbiology', 'Microscope', 'M0004', 'AmScope M150C-I', 45000),
('Arthur C Clarke Institute', 'Astrology', 'Telescope', 'T0001', 'Takahashi FSQ-106EDX4', 300000),
('Arthur C Clarke Institute', 'Astrology', 'Telescope', 'T0002', 'Takahashi FSQ-85EDX', 200000),
('Arthur C Clarke Institute', 'Astrology', 'Telescope', 'T0003', 'Celestron 21035', 40000),
('Arthur C Clarke Institute', 'Astrology', 'Telescope', 'T0004', 'Celestron 21035', 35000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `instru`
--
ALTER TABLE `instru`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
