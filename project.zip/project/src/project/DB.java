package project;

import java.sql.*;

public class DB {

	public static Connection getConnection() throws Exception 
	{
	
			
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/instruments", "root", "");
				return conn;
			
			
			
		
		
	}

	
}
