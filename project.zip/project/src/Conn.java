

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import project.DB;

/**
 * Servlet implementation class Conn
 */
@WebServlet("/Conn")
public class Conn extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Conn() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String a=request.getParameter("institute");
		String b=request.getParameter("category");
		String c=request.getParameter("type");
		String d=request.getParameter("sort");
		String f=request.getParameter("search");
		
				
					Connection cc = null;
					try {
						cc = DB.getConnection();
					} catch (Exception e) {
					
						e.printStackTrace();
					}
				
	    
		
			Statement st = null;
			try {
				st = cc.createStatement();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
	    String sql = null;
		if(!f.equals(""))
	    {
	    if((d.equals("Low to High Price"))&&(a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
	    { sql = "select * from instru where ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee ASC";
	    
	    }
	    else if((d.equals("Low to High Price"))&&(a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
	    {
	    	sql = "select * from instru where Instument_Type='"+c+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee ASC";
	    
	    }
	    else if((d.equals("Low to High Price"))&&(a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
	    {
	    	sql = "select * from instru where Category='"+b+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee ASC";
	    }
	    else if((d.equals("Low to High Price"))&&(!a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
	    {
	    	sql = "select * from instru where Institute='"+a+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee ASC";
	    }
	    else if((d.equals("Low to High Price"))&&(!a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
	    {
	    	sql="select * from instru where Institute='"+a+"' and Category='"+b+"' and Instument_Type='"+c+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee ASC";
	    	
	    }
	    
	    else if((d.equals("Low to High Price"))&&(!a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
	    {
	    	sql="select * from instru where Institute='"+a+"' and Instument_Type='"+c+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or(Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee ASC";
	    }
	    else if((d.equals("Low to High Price"))&&(!a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
	    {
	    	sql="select * from instru where Institute='"+a+"' and Category='"+b+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee ASC";
	    	
	    }
	    else if((d.equals("Low to High Price"))&&(a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
	    {
	    	sql="select * from instru where Category='"+b+"' and Instument_Type='"+c+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee ASC";
	    }
	    
	    else if((d.equals("High to Low Price"))&&(a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
	    { sql = "select * from instru where ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee DESC";}
	    else if((d.equals("High to Low Price"))&&(a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
	    {
	    	 sql = "select * from instru where Instument_Type='"+c+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee DESC";
	    
	    }
	    else if((d.equals("High to Low Price"))&&(a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
	    {
	    	 sql = "select * from instru where Category='"+b+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee DESC";
	    }
	    else if((d.equals("High to Low Price"))&&(!a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
	    {
	    	 sql = "select * from instru where Institute='"+a+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee DESC";
	    }
	    else if((d.equals("High to Low Price"))&&(!a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
	    {
	    	 sql="select * from instru where Institute='"+a+"' and Category='"+b+"' and Instument_Type='"+c+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee DESC";
	    }
	    else if((d.equals("High to Low Price"))&&(!a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
	    {
	    	 sql="select * from instru where Institute='"+a+"' and Instument_Type='"+c+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee DESC";
	    }
	    else if((d.equals("High to Low Price"))&&(!a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
	    {
	    	 sql="select * from instru where Institute='"+a+"' and Category='"+b+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee DESC";
	    	
	    }
	    else 
	    {
	    	 sql="select * from instru where Category='"+b+"' and Instument_Type='"+c+"' and ((Instument_Type LIKE CONCAT('%','"+f+"','%')) or (Model LIKE CONCAT('%','"+f+"','%')) or (Institute LIKE CONCAT('%','"+f+"','%')))"+"ORDER BY Fee DESC";
	    }}
		
	    else
	    {
	    	if((d.equals("Low to High Price"))&&(a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
		    {  sql = "select * from instru ORDER BY Fee ASC";}
		    else if((d.equals("Low to High Price"))&&(a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
		    {
		    	 sql = "select * from instru where Instument_Type='"+c+"'"+"ORDER BY Fee ASC";
		    
		    }
		    else if((d.equals("Low to High Price"))&&(a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
		    {
		    	 sql = "select * from instru where Category='"+b+"'"+"ORDER BY Fee ASC";
		    }
		    else if((d.equals("Low to High Price"))&&(!a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
		    {
		    	sql = "select * from instru where Institute='"+a+"'"+"ORDER BY Fee ASC";
		    }
		    else if((d.equals("Low to High Price"))&&(!a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
		    {
		    	  sql="select * from instru where Institute='"+a+"' and Category='"+b+"' and Instument_Type='"+c+"'"+"ORDER BY Fee ASC";
		    }
		    else if((d.equals("Low to High Price"))&&(!a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
		    {
		    	sql="select * from instru where Institute='"+a+"' and Instument_Type='"+c+"'"+"ORDER BY Fee ASC";
		    }
		    else if((d.equals("Low to High Price"))&&(!a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
		    {
		    	sql="select * from instru where Institute='"+a+"' and Category='"+b+"'"+"ORDER BY Fee ASC";
		    	
		    }
		    else if((d.equals("Low to High Price"))&&(a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
		    {
		    	 sql="select * from instru where Category='"+b+"' and Instument_Type='"+c+"'"+"ORDER BY Fee ASC";
		    }
		    
		    else if((d.equals("High to Low Price"))&&(a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
		    {  sql = "select * from instru ORDER BY Fee DESC";}
		    else if((d.equals("High to Low Price"))&&(a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
		    {
		    	 sql = "select * from instru where Instument_Type='"+c+"'"+"ORDER BY Fee DESC";
		    
		    }
		    else if((d.equals("High to Low Price"))&&(a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
		    {
		    	 sql = "select * from instru where Category='"+b+"'"+"ORDER BY Fee DESC";
		    }
		    else if((d.equals("High to Low Price"))&&(!a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
		    {
		    	sql = "select * from instru where Institute='"+a+"'"+"ORDER BY Fee DESC";
		    }
		    else if((d.equals("High to Low Price"))&&(!a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
		    {
		    	  sql="select * from instru where Institute='"+a+"' and Category='"+b+"' and Instument_Type='"+c+"'"+"ORDER BY Fee DESC";
		    }
		    else if((d.equals("High to Low Price"))&&(!a.equals("--Select an Option--"))&&(b.equals("--Select an Option--"))&&(!c.equals("--Select an Option--")))
		    {
		    	 sql="select * from instru where Institute='"+a+"' and Instument_Type='"+c+"'"+"ORDER BY Fee DESC";
		    }
		    else if((d.equals("High to Low Price"))&&(!a.equals("--Select an Option--"))&&(!b.equals("--Select an Option--"))&&(c.equals("--Select an Option--")))
		    {
		    	 sql="select * from instru where Institute='"+a+"' and Category='"+b+"'"+"ORDER BY Fee DESC";
		    	
		    }
		    else 
		    {
		    	 sql="select * from instru where Category='"+b+"' and Instument_Type='"+c+"'"+"ORDER BY Fee DESC";
		    }
	    	
	    }
	    
	    
	    ResultSet rs = null;
			try {
				
				rs = st.executeQuery(sql);
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
			out.println("<table><tr><th>Institute</th><th>Model</th><th>Fee(in Rs.)</th></tr>");
			try {
				while(rs.next())
				{out.println("<br>");
				
					String in=rs.getString("Institute");
				
				String model=rs.getString("Model");
				String fee=rs.getString("Fee");
				out.println("<tr><td>"+in+"</td><td>"+model+"</td><td>"+fee+"</td></tr>");
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			out.println("</table>");
			
			try {
				st.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
			try {
				cc.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
			RequestDispatcher rd=request.getRequestDispatcher("result.jsp");
			rd.include(request, response);
			
		
	}}
	

